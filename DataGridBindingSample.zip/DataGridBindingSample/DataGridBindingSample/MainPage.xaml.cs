﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace DataGridBindingSample
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            // McDataGrid.AutoGenerateColumns = false;
            McDataGrid.ItemsSource = LoadCollectionData();

            Style dgHeaderStyle = new Style(typeof(DataGridRowHeader));
            dgHeaderStyle.Setters.Add(new Setter(DataGridRowHeader.FontFamilyProperty, "Verdana"));
            dgHeaderStyle.Setters.Add(new Setter(DataGridRowHeader.FontSizeProperty, "40"));

            McDataGrid.SetValue(DataGrid.RowHeaderStyleProperty, dgHeaderStyle); 

           //  McDataGrid.ItemsSource = LoadStringData();
        }

        /// <summary>
        /// Load a string collection 
        /// </summary>
        /// <returns></returns>
        private string[] LoadStringData()
        { 
            return "One Two Three Four Five Six Seven Eight".Split();
        }


        /// <summary>
        /// List of Authors
        /// </summary>
        /// <returns></returns>
        private List<Author> LoadCollectionData()
        {
            List<Author> authors = new List<Author>();
            authors.Add(new Author(){
                    ID = 101, 
                    Name = "Mahesh Chand",
                    BookTitle = "Graphics Programming with GDI+",
                    DOB = new DateTime(1975, 2, 23),
                    IsMVP = false });
            authors.Add(new Author()
            {
                ID = 201,
                Name = "Mike Gold",
                BookTitle = "Programming C#",
                DOB = new DateTime(1982, 4, 12),
                IsMVP = true
            });
            authors.Add(new Author()
            {
                ID = 244,
                Name = "Mathew Cochran",
                BookTitle = "LINQ in Vista",
                DOB = new DateTime(1985, 9, 11),
                IsMVP = false
            });
            authors.Add(new Author()
            {
                ID = 133,
                Name = "Raj Kumar",
                BookTitle = "Silverlight Programming",
                DOB = new DateTime(1990, 12, 24),
                IsMVP = true
            });
            authors.Add(new Author()
            {
                ID = 123,
                Name = "Praveen Kumar",
                BookTitle = "VB.NET Web Development",
                DOB = new DateTime(1980, 6, 30),
                IsMVP = true
            });
            return authors;
        }


    }
}
